using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TabExample : MonoBehaviour
{
    public string stringVar1;
    public string stringVar2;
    public string stringVar3;
    public string stringVar4;
    public string stringVar5;

    public int intVar1;
    public int intVar2;
    public int intVar3;
    public int intVar4;
    public int intVar5;

    [HideInInspector]
    public int toolbarTop;
    public int toolbarBottom;
    public string currentTab;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
